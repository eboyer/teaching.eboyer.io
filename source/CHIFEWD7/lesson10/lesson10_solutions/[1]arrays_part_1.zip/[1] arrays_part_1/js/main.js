
// -------------------------------------------------------------------------------
// Part 1 - Compare two numbers! (use the cheat sheet for reference)
// -------------------------------------------------------------------------------

// 1. Declare a variable called "groceries" and assign it an array of strings: "milk", "eggs", "salmon", "asparagus"
var groceries = ["milk", "eggs", "salmon", "asparagus"];
console.log(groceries);

// 2. Add a fifth item to the array: "apples"
groceries[4] = "apples";
console.log(groceries);

// 3. Replace the second item in the array. The new value should be "brussel sprouts"
groceries[2] = "brussel sprouts";
console.log(groceries);

// 4. Add a sixth item to the array: "oranges"
groceries[5] = "oranges";
console.log(groceries);
