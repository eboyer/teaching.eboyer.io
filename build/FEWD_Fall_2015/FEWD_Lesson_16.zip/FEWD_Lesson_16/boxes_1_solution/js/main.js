$(function() {
	
	/* Your JS here */

	// After creating your functions below, if they need to run on page load put them here
	yourFunction();

});

// If you need to write functions create them down here
function yourFunction() {

}
