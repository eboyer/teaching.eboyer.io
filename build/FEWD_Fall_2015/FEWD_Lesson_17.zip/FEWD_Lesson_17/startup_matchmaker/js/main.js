$(document)ready({
	$(".js-togglenav").on("click", function(){
		$(this).next().toggleSlide(200);
	});	
});
